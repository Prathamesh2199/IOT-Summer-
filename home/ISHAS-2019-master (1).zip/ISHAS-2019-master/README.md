# ISHAS-2019
To provide strong Automation services which is efficient and economical and easily accessible to all income groups.
things required for project -:
1:-Arduino UNO, 2:-RTC-Timer Module, 3:-Relay Module, 4:-Ultrasonic Sensor, 5:-HC-05 Bluetooth Module or Wifi module etc.
Total Cost for project :- approx 3000 rupees
